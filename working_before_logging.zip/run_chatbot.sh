# run_chatbot.sh
#!/bin/bash
streamlit run streamlit_app.py --server.fileWatcherType none
